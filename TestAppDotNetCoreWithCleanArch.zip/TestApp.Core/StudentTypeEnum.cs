﻿using System;

namespace TestApp.Core
{
    public enum StudentTypeEnum
    {
        Deleted = 0
        , Active = 1
        , Pending = 2
        , Inactive = 3
    }
}